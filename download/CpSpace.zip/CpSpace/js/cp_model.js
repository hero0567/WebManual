var app = angular.module('myApp',[]);
app.controller('myCtrl',function($scope){
  // TODO: Read data from the json file
  $scope.items= [
       {
           "name": "ItemOne",
           "icon": "http://img1.tumunity.com/files/tsd/201203/17/13319890590909.jpg",
           "type": "3",
           "description": "this is test description"
       },
       {
           "name": "ItemOne",
           "icon": "http://img1.tumunity.com/files/tsd/201203/17/13319890590909.jpg",
           "type": "3",
           "description": "this is test description"
       }
   ];
});